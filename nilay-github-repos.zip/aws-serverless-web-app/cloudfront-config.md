# CloudFront Configuration Notes

## Distribution Settings

| Setting | Value |
|---|---|
| Origin Domain | `your-bucket.s3-website-REGION.amazonaws.com` |
| Origin Protocol | HTTP Only (S3 static website endpoint) |
| Viewer Protocol Policy | Redirect HTTP to HTTPS |
| Allowed HTTP Methods | GET, HEAD |
| Cache Policy | CachingOptimized (AWS Managed) |
| Price Class | Use All Edge Locations (best performance) |
| Default Root Object | `index.html` |

## Custom Error Pages (for SPA routing)

| HTTP Error Code | Response Page | HTTP Response Code |
|---|---|---|
| 403 | /index.html | 200 |
| 404 | /index.html | 200 |

## Cache Invalidation (after deploying updates)

```bash
aws cloudfront create-invalidation \
  --distribution-id YOUR_DISTRIBUTION_ID \
  --paths "/*"
```

## Security Headers (via CloudFront Functions)

Add a CloudFront Function to inject security headers:

```javascript
function handler(event) {
  var response = event.response;
  var headers = response.headers;

  headers['strict-transport-security'] = { value: 'max-age=63072000; includeSubdomains; preload' };
  headers['x-content-type-options'] = { value: 'nosniff' };
  headers['x-frame-options'] = { value: 'DENY' };
  headers['x-xss-protection'] = { value: '1; mode=block' };

  return response;
}
```
