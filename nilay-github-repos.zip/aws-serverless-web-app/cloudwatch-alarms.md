# CloudWatch Monitoring Setup

## Recommended Alarms for S3 + CloudFront

### 1. CloudFront 5xx Error Rate
- **Metric:** `5xxErrorRate`
- **Namespace:** `AWS/CloudFront`
- **Threshold:** > 5% for 5 minutes
- **Action:** SNS notification to email

### 2. CloudFront Total Requests
- **Metric:** `Requests`
- **Namespace:** `AWS/CloudFront`
- **Use:** Monitor traffic spikes

### 3. S3 4xx Errors
- **Metric:** `4xxErrors`
- **Namespace:** `AWS/S3`
- **Threshold:** > 10 per minute
- **Action:** SNS alert

---

## Setup via AWS CLI

```bash
# Create SNS topic for alerts
aws sns create-topic --name cloudfront-alerts
aws sns subscribe \
  --topic-arn arn:aws:sns:REGION:ACCOUNT_ID:cloudfront-alerts \
  --protocol email \
  --notification-endpoint nilay.meshram1998@gmail.com

# Create CloudFront 5xx alarm
aws cloudwatch put-metric-alarm \
  --alarm-name "CloudFront-5xx-Errors" \
  --metric-name "5xxErrorRate" \
  --namespace "AWS/CloudFront" \
  --statistic Average \
  --period 300 \
  --threshold 5 \
  --comparison-operator GreaterThanThreshold \
  --evaluation-periods 1 \
  --alarm-actions arn:aws:sns:REGION:ACCOUNT_ID:cloudfront-alerts
```

---

## Dashboard

Create a CloudWatch Dashboard with:
- Request count (line chart)
- 4xx / 5xx error rates (line chart)
- Cache hit rate (gauge)
- Bytes downloaded (area chart)
