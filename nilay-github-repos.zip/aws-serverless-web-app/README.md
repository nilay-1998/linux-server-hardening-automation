# Serverless Web Application on AWS

> Static website hosted on Amazon S3 with CloudFront CDN, IAM security policies, and CloudWatch monitoring.  
> Built by [Nilay Meshram](https://www.linkedin.com/in/nilay-meshram98) — AWS Cloud Engineer | Linux Administrator

---

## Architecture

```
Users → CloudFront (CDN + HTTPS) → S3 (Static Files)
                                        ↓
                               CloudWatch (Monitoring)
```

---

## Features

- Static file hosting via **Amazon S3**
- Global low-latency delivery via **CloudFront**
- Secure access using **IAM roles and bucket policies**
- HTTPS enforced via **CloudFront viewer protocol policy**
- Traffic and error monitoring via **CloudWatch dashboards and alarms**

---

## Files

| File | Purpose |
|---|---|
| `bucket-policy.json` | S3 IAM bucket policy for public read access |
| `cloudfront-config.md` | CloudFront distribution setup notes |
| `cloudwatch-alarms.md` | CloudWatch monitoring and alarm configuration |

---

## Deployment Steps

### 1. Create S3 Bucket
```bash
aws s3 mb s3://YOUR-BUCKET-NAME --region us-east-1
aws s3 website s3://YOUR-BUCKET-NAME \
  --index-document index.html \
  --error-document error.html
```

### 2. Apply Bucket Policy
```bash
# Edit bucket-policy.json — replace YOUR-BUCKET-NAME
aws s3api put-bucket-policy \
  --bucket YOUR-BUCKET-NAME \
  --policy file://bucket-policy.json
```

### 3. Upload Website Files
```bash
aws s3 sync ./website s3://YOUR-BUCKET-NAME --delete
```

### 4. Create CloudFront Distribution
See `cloudfront-config.md` for full settings.

### 5. Set Up Monitoring
See `cloudwatch-alarms.md` for alarm and dashboard setup.

---

## Requirements

- AWS CLI configured (`aws configure`)
- IAM user with S3, CloudFront, and CloudWatch permissions
- A static website (HTML/CSS/JS files)

---

## Author

**Nilay Meshram** — AWS Cloud Engineer | Linux Administrator  
[LinkedIn](https://www.linkedin.com/in/nilay-meshram98) | [GitHub](https://github.com/nilay-1998)
